.. _ref-index:

=============
API Reference
=============

.. toctree::
   :maxdepth: 4

   boto
   cloudformation
   cloudfront
   contrib
   dynamodb
   ec2
   ecs
   emr
   file
   fps
   gs
   iam
   manage
   mturk
   pyami
   rds
   route53 
   s3
   sdb
   services
   ses
   sns
   sqs
   sts
   vpc
 
